import { setupChatScreen } from '../../harness/chatHarness';

jest.mock('@react-navigation/native', () => ({
  useNavigation: () => ({ navigate: () => {}, goBack: () => {}, setOptions: () => {}, addListener: () => () => {} }),
  useRoute: () => require('../../harness/chatHarness').routeHolder,
  useFocusEffect: () => {}, useIsFocused: () => true,
}));

const dump = (h: any, tag: string) => {
  const input = h.view!.queryByTestId('chat-input');
  process.stderr.write(`[DBG] ${tag} conv=${h.conversationId} input=${JSON.stringify(input?.props.value)} rec=${!!h.view!.queryByTestId('voice-record-button')}\n`);
};

describe.each([['litert-direct', { engine: 'litert', audio: true }], ['llama-realtime', { engine: 'llama' }]] as const)('explore %s', (_n, o) => {
  it('hold in A, switch to B, release', async () => {
    const h = await setupChatScreen({ ...(o as any), platform: 'android', whisper: true });
    await h.setupWhisperModel('tiny.en');
    h.render();
    await h.send('hello from the first chat', o.engine === 'llama' ? { text: 'First chat reply.' } : { content: 'First chat reply.' });
    await h.rtl.waitFor(() => { expect(h.view!.queryAllByText(/First chat reply\./).length).toBeGreaterThan(0); });
    const chatA = h.conversationId!;
    await h.openConversation(chatA);
    h.boundary.whisper!.setFileTranscript('book the meeting room for friday');
    h.boundary.whisper!.holdNextTranscription();
    await h.tapMic();
    await h.settle(200);
    dump(h, 'held-in-A');
    await h.openConversation();
    dump(h, 'in-B-before-release');
    await h.releaseMic();
    await h.settle(200);
    if (o.engine === 'llama') {
      h.boundary.whisper!.emitRealtime({ text: 'book the meeting room for friday', isCapturing: false, recordingTime: 900 });
    }
    await h.rtl.act(async () => { h.boundary.whisper!.releaseTranscription(); await h.settle(400); });
    dump(h, 'in-B-after');
    await h.openConversation(chatA);
    await h.settle(200);
    dump(h, 'back-in-A');
  });
});

describe('control llama', () => {
  it('hold in A, release in A', async () => {
    const h = await setupChatScreen({ engine: 'llama', platform: 'android', whisper: true });
    await h.setupWhisperModel('tiny.en');
    h.render();
    await h.send('hello from the first chat', { text: 'First chat reply.' });
    await h.rtl.waitFor(() => { expect(h.view!.queryAllByText(/First chat reply\./).length).toBeGreaterThan(0); });
    const chatA = h.conversationId!;
    await h.openConversation(chatA);
    await h.tapMic();
    await h.rtl.waitFor(() => { expect(h.boundary.whisper!.hasRealtimeSubscriber()).toBe(true); });
    h.boundary.whisper!.emitRealtime({ text: 'book the', isCapturing: true, recordingTime: 300 });
    await h.releaseMic();
    await h.settle(100);
    h.boundary.whisper!.emitRealtime({ text: 'book the meeting room for friday', isCapturing: false, recordingTime: 900 });
    await h.rtl.waitFor(() => expect(h.view!.getByTestId('chat-input').props.value ?? '').toContain('friday'), { timeout: 3000 }).catch(() => {});
    process.stderr.write('[DBG] active=' + h.boundary.whisper!.realtimeActive() + '\n');
    dump(h, 'control-A');
  });
  it('hold in A, emit partial, switch to B, release, final', async () => {
    const h = await setupChatScreen({ engine: 'llama', platform: 'android', whisper: true });
    await h.setupWhisperModel('tiny.en');
    h.render();
    await h.send('hello from the first chat', { text: 'First chat reply.' });
    await h.rtl.waitFor(() => { expect(h.view!.queryAllByText(/First chat reply\./).length).toBeGreaterThan(0); });
    const chatA = h.conversationId!;
    await h.openConversation(chatA);
    await h.tapMic();
    await h.rtl.waitFor(() => { expect(h.boundary.whisper!.hasRealtimeSubscriber()).toBe(true); });
    h.boundary.whisper!.emitRealtime({ text: 'book the', isCapturing: true, recordingTime: 300 });
    await h.openConversation();
    process.stderr.write('[DBG] sub-after-switch=' + h.boundary.whisper!.hasRealtimeSubscriber() + ' active=' + h.boundary.whisper!.realtimeActive() + '\n');
    await h.releaseMic();
    await h.settle(100);
    h.boundary.whisper!.emitRealtime({ text: 'book the meeting room for friday', isCapturing: false, recordingTime: 900 });
    await h.settle(300);
    dump(h, 'switch-B');
    await h.openConversation(chatA);
    dump(h, 'switch-back-A');
  });
});
